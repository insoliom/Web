package com.example.binance;

import okhttp3.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

@Component
public class BinanceWebSocketTickerStreamClient {

    private static final Logger log = LoggerFactory.getLogger(BinanceWebSocketTickerStreamClient.class);
    private static final String WS_URL = "wss://stream.binance.com:9443/ws/!ticker@arr";

    private final OkHttpClient httpClient = new OkHttpClient();
    private final BinanceWebSocketMessageSerDe serDe;
    private final List<BinanceTickerUpdateListener> listeners = new CopyOnWriteArrayList<>();

    public BinanceWebSocketTickerStreamClient(BinanceWebSocketMessageSerDe serDe) {
        this.serDe = serDe;
    }

    public void registerListener(BinanceTickerUpdateListener listener) {
        listeners.add(listener);
    }

    @PostConstruct
    public void start() {
        Request request = new Request.Builder().url(WS_URL).build();
        httpClient.newWebSocket(request, new WebSocketListener() {
            @Override
            public void onOpen(WebSocket webSocket, Response response) {
                log.info("✅ Connected to Binance WS");
            }

            @Override
            public void onMessage(WebSocket webSocket, String text) {
                try {
                    BinanceTickerMessage[] messages = serDe.deserializeArray(text);
                    for (BinanceTickerMessage msg : messages) {
                        for (BinanceTickerUpdateListener listener : listeners) {
                            listener.onUpdate(msg);
                        }
                    }
                } catch (Exception e) {
                    log.error("❌ Failed to parse message", e);
                }
            }

            @Override
            public void onFailure(WebSocket webSocket, Throwable t, Response response) {
                log.error("❌ WebSocket Failure", t);
            }
        });
    }
}
