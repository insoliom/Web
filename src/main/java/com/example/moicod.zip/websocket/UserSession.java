package com.example.websocket;

import org.springframework.web.socket.WebSocketSession;

public class UserSession {
    private final String userId;
    private final WebSocketSession session;

    public UserSession(String userId, WebSocketSession session) {
        this.userId = userId;
        this.session = session;
    }

    public String getUserId() {
        return userId;
    }

    public WebSocketSession getSession() {
        return session;
    }

    @Override
    public int hashCode() {
        return session.getId().hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        return obj instanceof UserSession us && session.getId().equals(us.getSession().getId());
    }
}
