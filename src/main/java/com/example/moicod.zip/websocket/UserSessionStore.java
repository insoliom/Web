package com.example.websocket;

import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class UserSessionStore {
    // userId -> set of sessions
    private final Map<String, Set<UserSession>> sessions = new ConcurrentHashMap<>();

    public void add(UserSession userSession) {
        sessions
                .computeIfAbsent(userSession.getUserId(), id -> ConcurrentHashMap.newKeySet())
                .add(userSession);
    }

    public void remove(UserSession userSession) {
        Set<UserSession> set = sessions.get(userSession.getUserId());
        if (set != null) {
            set.remove(userSession);
            if (set.isEmpty()) {
                sessions.remove(userSession.getUserId());
            }
        }
    }

    public Collection<UserSession> all() {
        return sessions.values()
                .stream()
                .flatMap(Set::stream)
                .toList();
    }
}
