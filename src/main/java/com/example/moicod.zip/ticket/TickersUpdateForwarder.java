package com.example.ticket;

/**
 * Интерфейс для регистрации слушателей обновлений тикера.
 */
public interface TickersUpdateForwarder {
    /**
     * Регистрирует слушатель для получения событий.
     */
    void registerListener(TickerUpdateListener listener);
}