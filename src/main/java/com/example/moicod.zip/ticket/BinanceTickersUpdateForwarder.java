package com.example.ticket;

import com.example.binance.*;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

@Component
public class BinanceTickersUpdateForwarder implements TickersUpdateForwarder, BinanceTickerUpdateListener {

    private final List<TickerUpdateListener> listeners = new CopyOnWriteArrayList<>();

    public BinanceTickersUpdateForwarder(BinanceWebSocketTickerStreamClient binanceClient) {
        binanceClient.registerListener(this);
    }

    @Override
    public void onUpdate(BinanceTickerMessage msg) {
        try {
            Coin coin = Coin.fromSymbol(msg.getSymbol());
            TickerUpdate update = new TickerUpdate(coin, msg.getPrice(), msg.getEventTime());
            for (var l : listeners) {
                l.onUpdate(update);
            }
        } catch (IllegalArgumentException ignored) {}
    }

    @Override
    public void registerListener(TickerUpdateListener listener) {
        listeners.add(listener);
    }
}

