package com.example.ticket;

/**
 * Перелік підтримуваних монет.
 */
public enum Coin {
    BTC("BTC"),
    ETH("ETH"),
    DOGE("DOGE"),
    XRP("XRP");
    // додайте сюди інші, які вам потрібні

    private final String symbol;

    Coin(String symbol) {
        this.symbol = symbol;
    }

    public String getSymbol() {
        return symbol;
    }

    /** Конвертує рядок у Coin, кидає IllegalArgumentException при невідомому символі */
    public static Coin fromSymbol(String symbol) {
        for (Coin c : values()) {
            if (c.symbol.equalsIgnoreCase(symbol)) {
                return c;
            }
        }
        throw new IllegalArgumentException("Unknown coin symbol: " + symbol);
    }
}
