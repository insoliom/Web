package com.example.ticket;

@FunctionalInterface
public interface TickerUpdateListener {
    /**
     * Викликається при кожному новому оновленні тікера.
     * @param update — доменна модель з полями coin, price, timestamp
     */
    void onUpdate(TickerUpdate update);
}

