package com.example.binance;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Подключается к Binance WS и рассылает десериализованные сообщения
 * всем зарегистрированным слушателям.
 */
@Component
public class BinanceWebSocketTickerStreamClient {

    private static final Logger log = LoggerFactory.getLogger(BinanceWebSocketTickerStreamClient.class);
    private static final String WS_URL = "wss://stream.binance.com:9443/ws/!ticker@arr";

    private final OkHttpClient httpClient = new OkHttpClient();
    private final BinanceWebSocketMessageSerDe serDe;
    private final BinanceTickerMessageHandler messageHandler;

    /** Потокобезопасный список слушателей обновлений тикера */
    private final List<BinanceTickerUpdateListener> listeners = new CopyOnWriteArrayList<>();

    public BinanceWebSocketTickerStreamClient(BinanceWebSocketMessageSerDe serDe,
                                              BinanceTickerMessageHandler messageHandler) {
        this.serDe = serDe;
        this.messageHandler = messageHandler;
    }

    /**
     * Позволяет любому компоненту подписаться на события тиков из Binance.
     */
    public void registerListener(BinanceTickerUpdateListener listener) {
        listeners.add(listener);
    }

    /**
     * После старта Spring запускаем WS-подключение к Binance.
     */
    @PostConstruct
    public void start() {
        Request req = new Request.Builder()
                .url(WS_URL)
                .build();

        httpClient.newWebSocket(req, new WebSocketListener() {
            @Override
            public void onOpen(WebSocket webSocket, Response response) {
                log.info("Connected to Binance WS");
            }

            @Override
            public void onMessage(WebSocket webSocket, String text) {
                try {
                    // 1) Десериализуем raw JSON в BinanceTickerMessage
                    BinanceTickerMessage msg = serDe.deserialize(text);
                    // 2) Ваша внутренняя обработка (логирование, доп. бизнес-логика)
                    messageHandler.handle(msg);
                    // 3) Рассылаем всем зарегистрированным слушателям
                    for (var l : listeners) {
                        l.onUpdate(msg);
                    }
                } catch (Exception ex) {
                    log.error("Error handling Binance message", ex);
                }
            }

            @Override
            public void onFailure(WebSocket webSocket, Throwable t, Response response) {
                log.error("Binance WS failure", t);
                // TODO: можно попытаться переподключиться
            }
        });
        // не закрываем httpClient, чтобы WS-соединение оставалось активным
    }
}

