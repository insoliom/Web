package com.example.binance;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Component;

@Component
public class BinanceWebSocketMessageSerDe {
    private static final ObjectMapper mapper = new ObjectMapper();

    /**
     * Преобразует «сырую» JSON-строку из Binance в наш BinanceTickerMessage.
     * Ожидается, что это сообщение типа 24-hour ticker или miniTicker.
     */
    public BinanceTickerMessage deserialize(String rawJson) {
        try {
            JsonNode root = mapper.readTree(rawJson);
            // пример для агрегированного тика (aggTrade)
            String symbol = root.path("s").asText();           // поле "s"
            double price = root.path("c").asDouble();          // поле "c" = last price
            long eventTime = root.path("E").asLong();          // поле "E" = event time
            return new BinanceTickerMessage(symbol, price, eventTime);
        } catch (Exception ex) {
            throw new BinanceMessageSerializationException("Ошибка десериализации", ex);
        }
    }
}

