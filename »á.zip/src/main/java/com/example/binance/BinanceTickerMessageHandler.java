package com.example.binance;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class BinanceTickerMessageHandler {
    private static final Logger log = LoggerFactory.getLogger(BinanceTickerMessageHandler.class);

    public void handle(BinanceTickerMessage msg) {
        log.info("Received Binance tick: {} = {} @ {}",
                msg.getSymbol(), msg.getPrice(), msg.getEventTime());
    }
}
