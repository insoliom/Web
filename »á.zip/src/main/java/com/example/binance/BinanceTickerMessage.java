package com.example.binance;

public class BinanceTickerMessage {
    private String symbol;
    private double price;
    private long eventTime;

    public BinanceTickerMessage() { }

    public BinanceTickerMessage(String symbol, double price, long eventTime) {
        this.symbol = symbol;
        this.price = price;
        this.eventTime = eventTime;
    }

    // getters / setters
    public String getSymbol() { return symbol; }
    public void setSymbol(String symbol) { this.symbol = symbol; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public long getEventTime() { return eventTime; }
    public void setEventTime(long eventTime) { this.eventTime = eventTime; }
}
