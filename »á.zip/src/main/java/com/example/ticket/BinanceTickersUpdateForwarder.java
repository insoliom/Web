package com.example.ticket;

import com.example.binance.BinanceTickerMessage;
import com.example.binance.BinanceWebSocketTickerStreamClient;
import com.example.binance.BinanceTickerUpdateListener;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Подписывается на поток сообщений из BinanceWebSocketTickerStreamClient,
 * конвертирует их в доменную модель TickerUpdate и рассылает
 * всем зарегистрированным слушателям.
 */
@Component
public class BinanceTickersUpdateForwarder
        implements TickersUpdateForwarder, BinanceTickerUpdateListener {

    private final BinanceWebSocketTickerStreamClient binanceClient;
    private final List<TickerUpdateListener> listeners = new CopyOnWriteArrayList<>();

    public BinanceTickersUpdateForwarder(BinanceWebSocketTickerStreamClient binanceClient) {
        this.binanceClient = binanceClient;
    }

    @PostConstruct
    public void init() {
        // Подписываемся на обновления от Binance-клиента
        binanceClient.registerListener(this);
    }

    @Override
    public void registerListener(TickerUpdateListener listener) {
        listeners.add(listener);
    }

    /**
     * Коллбэк от BinanceWebSocketTickerStreamClient.
     */
    @Override
    public void onUpdate(BinanceTickerMessage msg) {
        String symbol = msg.getSymbol();
        // Если символ пустой или null — пропускаем
        if (symbol == null || symbol.isBlank()) {
            return;
        }
        // Пробуем сконвертировать символ в Coin, игнорируем неизвестные
        Coin coin;
        try {
            coin = Coin.fromSymbol(symbol);
        } catch (IllegalArgumentException ex) {
            // неподдерживаемая монета — пропускаем
            return;
        }
        // Формируем доменное обновление и рассылаем его слушателям
        TickerUpdate update = new TickerUpdate(
                coin,
                msg.getPrice(),
                msg.getEventTime()
        );
        for (TickerUpdateListener l : listeners) {
            l.onUpdate(update);
        }
    }
}

