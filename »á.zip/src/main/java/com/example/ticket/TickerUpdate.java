package com.example.ticket;

/**
 * Доменная модель обновления цены криптовалюты.
 */
public class TickerUpdate {
    private Coin coin;
    private double price;
    private long timestamp;

    public TickerUpdate() { }

    public TickerUpdate(Coin coin, double price, long timestamp) {
        this.coin = coin;
        this.price = price;
        this.timestamp = timestamp;
    }

    public Coin getCoin() { return coin; }
    public void setCoin(Coin coin) { this.coin = coin; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }

    /**
     * Сериализует объект в JSON-строку для WebSocket.
     */
    public String toJsonString() {
        return String.format(
                "{\"coin\":\"%s\",\"price\":%.8f,\"timestamp\":%d}",
                coin.getSymbol(), price, timestamp
        );
    }
}
