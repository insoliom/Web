package com.example.websocket;

import com.example.ticket.TickerUpdate;
import com.example.ticket.TickersUpdateForwarder;
import com.example.ticket.TickerUpdateListener;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.*;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.util.Map;

@Component
public class UserWebSocketHandler implements WebSocketHandler, TickerUpdateListener {

    private final UserSessionStore sessionStore;
    private final TickersUpdateForwarder forwarder;

    public UserWebSocketHandler(UserSessionStore sessionStore,
                                TickersUpdateForwarder forwarder) {
        this.sessionStore = sessionStore;
        this.forwarder = forwarder;
    }

    @PostConstruct
    public void init() {
        // подписываемся на домен-обновления
        forwarder.registerListener(this);
    }

    @Override
    public void afterConnectionEstablished(WebSocketSession session) {
        Map<String, Object> attrs = session.getAttributes();
        String userId = (String) attrs.get("userId");
        sessionStore.add(new UserSession(userId, session));
    }

    @Override
    public void handleMessage(WebSocketSession session, WebSocketMessage<?> message) { }

    @Override
    public void handleTransportError(WebSocketSession session, Throwable exception) {
        close(session);
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) {
        close(session);
    }

    @Override
    public boolean supportsPartialMessages() {
        return false;
    }

    private void close(WebSocketSession session) {
        String userId = (String) session.getAttributes().get("userId");
        sessionStore.remove(new UserSession(userId, session));
    }

    /** Коллбэк на каждое доменное обновление тикера */
    @Override
    public void onUpdate(TickerUpdate update) {
        String payload = update.toJsonString();
        for (UserSession us : sessionStore.all()) {
            try {
                us.getSession().sendMessage(new TextMessage(payload));
            } catch (IOException e) {
                // логировать по необходимости
            }
        }
    }
}
