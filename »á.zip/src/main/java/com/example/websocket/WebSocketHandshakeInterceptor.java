package com.example.websocket;

import com.example.jwt.JwtDecoder;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.WebSocketHandler;
import org.springframework.web.socket.server.HandshakeInterceptor;

import java.util.Map;

@Component
public class WebSocketHandshakeInterceptor implements HandshakeInterceptor {

    private final JwtDecoder jwtDecoder;
    private final UserSessionStore sessionStore;

    public WebSocketHandshakeInterceptor(JwtDecoder jwtDecoder,
                                         UserSessionStore sessionStore) {
        this.jwtDecoder = jwtDecoder;
        this.sessionStore = sessionStore;
    }

    @Override
    public boolean beforeHandshake(ServerHttpRequest request,
                                   ServerHttpResponse response,
                                   WebSocketHandler wsHandler,
                                   Map<String, Object> attributes) throws Exception {
        String query = request.getURI().getQuery();
        if (query == null || !query.startsWith("token=")) {
            return false;
        }
        String token = query.substring("token=".length());
        var claims = jwtDecoder.decodeToken(token);
        String userId = (String) claims.get("userId");
        if (userId == null) {
            return false;
        }
        attributes.put("userId", userId);
        return true;
    }

    @Override
    public void afterHandshake(ServerHttpRequest request,
                               ServerHttpResponse response,
                               WebSocketHandler wsHandler,
                               Exception exception) {
    }
}
