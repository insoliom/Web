package com.example.config;

import org.springframework.boot.autoconfigure.security.servlet.PathRequest;
import org.springframework.context.annotation.*;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.*;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                // 1) Отключаем CSRF только для WS-handshake:
                .csrf(csrf -> csrf
                        .ignoringRequestMatchers(new AntPathRequestMatcher("/coins/**"))
                )

                // 2) Разрешаем без auth все ваши REST-контроллеры и фронт
                .authorizeHttpRequests(auth -> auth
                        // WebSocket-handshake:
                        .requestMatchers(HttpMethod.GET, "/coins/**").permitAll()

                        // Ваши публичные REST-контроллеры:
                        .requestMatchers(HttpMethod.POST, "/auth/**").permitAll()
                        .requestMatchers(HttpMethod.GET, "/config", "/userinfo").permitAll()

                        // Статика и index:
                        .requestMatchers(PathRequest.toStaticResources().atCommonLocations()).permitAll()
                        .requestMatchers("/", "/index.html", "/favicon.ico").permitAll()

                        // Всё остальное (если есть), тоже можно сделать публичным или запретить:
                        .anyRequest().permitAll()
                )

                // 3) Отключаем сессии — у вас JWT в куки / вручную:
                .sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS));

        return http.build();
    }
}
